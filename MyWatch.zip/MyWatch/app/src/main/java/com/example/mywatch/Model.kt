package com.example.mywatch

import java.util.UUID

data class WatchState(
    val status: String = "Disconnected",
    val connected: Boolean = false,
    val hr: Int? = null,
    val battery: Int? = null,
    val steps: Int? = null,
    val sleepMin: Int? = null,
    val weather: String? = null,
    val lastSync: Long = 0
)

fun u16(x: Int): UUID = UUID.fromString(String.format("0000%04x-0000-1000-8000-00805f9b34fb", x))

/** What the protocol can ask the BLE layer to do. */
interface Io {
    fun write(char: UUID, data: ByteArray)
    fun read(char: UUID)
    fun subscribe(char: UUID)
}

/**
 * THE ONLY PART THAT IS WATCH-SPECIFIC.
 * Standard Heart Rate (0x180D) and Battery (0x180F) work on many watches out of the box.
 * Steps, sleep, notifications, weather and time-sync use vendor-private commands:
 * fill them in after capturing your watch's traffic (see README).
 */
interface WatchProtocol {
    fun onReady(io: Io) {}
    fun onData(char: UUID, data: ByteArray, s: WatchState): WatchState = s
    fun timeSync(): Pair<UUID, ByteArray>? = null
    fun notification(app: String, title: String, text: String): Pair<UUID, ByteArray>? = null
    fun weather(tempC: Int, wmoCode: Int): Pair<UUID, ByteArray>? = null
}

class GenericProtocol : WatchProtocol {
    private val hr = u16(0x2A37)
    private val bat = u16(0x2A19)

    override fun onReady(io: Io) {
        io.subscribe(hr)
        io.read(bat)
        // TODO vendor: io.subscribe(<vendor notify char>) to receive steps / sleep packets
    }

    override fun onData(char: UUID, data: ByteArray, s: WatchState): WatchState = when (char) {
        hr -> {
            val v = if (data.isNotEmpty() && (data[0].toInt() and 1) == 0) data.getOrNull(1)?.toInt()?.and(0xFF)
            else if (data.size >= 3) ((data[2].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF) else null
            s.copy(hr = v?.takeIf { it in 30..220 })
        }
        bat -> s.copy(battery = data.firstOrNull()?.toInt()?.and(0xFF))
        else -> s // TODO vendor: parse steps/sleep here
    }

    // TODO vendor: return (writeCharUuid, bytes) for each of these once the packet format is known.
    override fun timeSync(): Pair<UUID, ByteArray>? = null
    override fun notification(app: String, title: String, text: String): Pair<UUID, ByteArray>? = null
    override fun weather(tempC: Int, wmoCode: Int): Pair<UUID, ByteArray>? = null
}

package com.example.mywatch

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleService : Service() {
    companion object {
        val state = MutableStateFlow(WatchState())
        var instance: BleService? = null
        const val CCCD = "00002902-0000-1000-8000-00805f9b34fb"
        fun start(ctx: Context) = ctx.startForegroundService(Intent(ctx, BleService::class.java))
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val protocol: WatchProtocol = GenericProtocol()
    private var gatt: BluetoothGatt? = null
    private var attempts = 0
    private val queue = ArrayDeque<() -> Boolean>()
    private var busy = false
    private var lastWeather: Pair<Int, Int>? = null

    private fun addr() = getSharedPreferences("w", 0).getString("addr", null)
    private fun upd(f: (WatchState) -> WatchState) { state.value = f(state.value) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val ch = NotificationChannel("ble", "Watch connection", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "ble")
            .setContentTitle("MyWatch").setContentText("Keeping your watch connected")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).build())
        // Watchdog: if we should be connected but aren't, reconnect.
        scope.launch { while (true) { delay(45_000); if (addr() != null && !state.value.connected && gatt == null) connect() } }
        // Weather refresh every 30 min.
        scope.launch(Dispatchers.IO) { while (true) { refreshWeather(); delay(30 * 60_000L) } }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int { connect(); return START_STICKY }

    override fun onDestroy() { instance = null; gatt?.close(); scope.cancel(); super.onDestroy() }

    // ---------- connection ----------
    fun connect() {
        val a = addr() ?: return
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (!adapter.isEnabled) { upd { it.copy(status = "Bluetooth is off") }; return }
        gatt?.close(); gatt = null
        upd { it.copy(status = "Connecting…") }
        val dev = adapter.getRemoteDevice(a)
        // First try fast direct connect, afterwards autoConnect (more reliable for background reconnects).
        gatt = dev.connectGatt(this, attempts > 0, cb, BluetoothDevice.TRANSPORT_LE)
    }

    fun forget() {
        getSharedPreferences("w", 0).edit().remove("addr").apply()
        gatt?.disconnect(); gatt?.close(); gatt = null
        upd { WatchState() }
    }

    private fun scheduleReconnect() {
        gatt?.close(); gatt = null
        attempts++
        val delayMs = minOf(60_000L, 2_000L * (1L shl minOf(attempts, 5)))
        upd { it.copy(connected = false, status = "Reconnecting in ${delayMs / 1000}s…") }
        main.postDelayed({ connect() }, delayMs)
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    upd { it.copy(status = "Discovering…") }
                    g.discoverServices()
                } else scheduleReconnect()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                attempts = 0
                queue.clear(); busy = false
                upd { it.copy(connected = true, status = "Connected", lastSync = System.currentTimeMillis()) }
                protocol.onReady(io)
                protocol.timeSync()?.let { io.write(it.first, it.second) }   // fixes "time not in sync"
                lastWeather?.let { sendWeather(it.first, it.second) }
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            main.post { handle(c.uuid, c.value ?: ByteArray(0)); next() }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            main.post { handle(c.uuid, c.value ?: ByteArray(0)) }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, v: ByteArray) {
            main.post { handle(c.uuid, v) }
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) { main.post { next() } }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) { main.post { next() } }
    }

    private fun handle(u: UUID, d: ByteArray) {
        upd { protocol.onData(u, d, it).copy(lastSync = System.currentTimeMillis()) }
    }

    // ---------- serialized GATT operations ----------
    private fun enqueue(op: () -> Boolean) { queue.add(op); if (!busy) next() }
    private fun next() {
        val op = queue.removeFirstOrNull()
        if (op == null) { busy = false; return }
        busy = true
        if (!op()) next()
    }
    private fun find(u: UUID): BluetoothGattCharacteristic? =
        gatt?.services?.flatMap { it.characteristics }?.firstOrNull { it.uuid == u }

    private val io = object : Io {
        override fun write(char: UUID, data: ByteArray) = enqueue {
            val c = find(char) ?: return@enqueue false
            c.value = data; gatt?.writeCharacteristic(c) ?: false
        }
        override fun read(char: UUID) = enqueue {
            val c = find(char) ?: return@enqueue false
            gatt?.readCharacteristic(c) ?: false
        }
        override fun subscribe(char: UUID) = enqueue {
            val c = find(char) ?: return@enqueue false
            gatt?.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(UUID.fromString(CCCD)) ?: return@enqueue false
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt?.writeDescriptor(d) ?: false
        }
    }

    // ---------- notifications & weather ----------
    fun sendNotification(app: String, title: String, text: String) {
        if (!state.value.connected) return
        protocol.notification(app, title, text)?.let { io.write(it.first, it.second) }
    }

    private fun sendWeather(t: Int, code: Int) {
        protocol.weather(t, code)?.let { io.write(it.first, it.second) }
    }

    private suspend fun refreshWeather() {
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc = listOf("fused", "network", "passive", "gps").mapNotNull {
                try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
            }.maxByOrNull { it.time }
            val prefs = getSharedPreferences("w", 0)
            if (loc != null) prefs.edit().putFloat("lat", loc.latitude.toFloat()).putFloat("lon", loc.longitude.toFloat()).apply()
            val lat = prefs.getFloat("lat", Float.NaN); val lon = prefs.getFloat("lon", Float.NaN)
            if (lat.isNaN()) return
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000; c.readTimeout = 10_000
            val cur = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("current")
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val code = cur.getInt("weather_code")
            withContext(Dispatchers.Main) {
                lastWeather = t to code
                upd { it.copy(weather = "$t°C") }
                if (state.value.connected) sendWeather(t, code)
            }
        } catch (_: Exception) { /* offline: keep last value */ }
    }
}

package com.example.mywatch

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date

@SuppressLint("MissingPermission")
class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme { Surface { Screen() } } }
    }

    @Composable
    fun Screen() {
        val s by BleService.state.collectAsStateWithLifecycle()
        val found = remember { mutableStateListOf<BluetoothDevice>() }
        var scanning by remember { mutableStateOf(false) }
        val perms = buildList {
            if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_CONNECT) }
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        LaunchedEffect(Unit) { launcher.launch(perms) }

        val scanCb = remember {
            object : ScanCallback() {
                override fun onScanResult(t: Int, r: ScanResult) {
                    if (found.none { it.address == r.device.address } && !r.device.name.isNullOrBlank()) found.add(r.device)
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("MyWatch", style = MaterialTheme.typography.headlineMedium) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.status, style = MaterialTheme.typography.titleMedium)
                        Text("Battery: ${s.battery?.let { "$it%" } ?: "—"}")
                        Text("Heart rate: ${s.hr?.let { "$it bpm" } ?: "—"}")
                        Text("Steps: ${s.steps ?: "—"}")
                        Text("Sleep: ${s.sleepMin?.let { "${it / 60}h ${it % 60}m" } ?: "—"}")
                        Text("Weather: ${s.weather ?: "—"}")
                        if (s.lastSync > 0) Text("Last sync: " + DateFormat.getTimeInstance().format(Date(s.lastSync)))
                        Text("Readings are estimates, not medical advice.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val sc = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner
                        if (!scanning) { found.clear(); sc.startScan(scanCb); scanning = true }
                        else { sc.stopScan(scanCb); scanning = false }
                    }) { Text(if (scanning) "Stop scan" else "Scan") }
                    OutlinedButton(onClick = { BleService.instance?.connect() ?: BleService.start(this@MainActivity) }) { Text("Reconnect") }
                    OutlinedButton(onClick = { BleService.instance?.forget() }) { Text("Forget") }
                }
            }
            item {
                OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                    Text("Allow notifications to watch")
                }
            }
            item { Text("Nearby devices", style = MaterialTheme.typography.titleMedium) }
            items(found) { d ->
                OutlinedButton(onClick = {
                    (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner.stopScan(scanCb)
                    scanning = false
                    getSharedPreferences("w", 0).edit().putString("addr", d.address).apply()
                    BleService.start(this@MainActivity)
                    BleService.instance?.connect()
                }, modifier = Modifier.fillMaxWidth()) { Text("${d.name}  (${d.address})") }
            }
            item { Text("Tip: disable battery optimization for this app so the connection survives in the background.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

package com.example.mywatch

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    // لو النظام فصل الخدمة (بيحصل كتير على أجهزة معينة)، نطلب إعادة الربط.
    override fun onListenerDisconnected() {
        try { requestRebind(ComponentName(this, NotifListener::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = getSharedPreferences("w", 0)
        if (!p.getBoolean("notif_enabled", true)) return
        if (sbn.packageName == packageName) return
        val blocked = p.getStringSet("blocked", emptySet()) ?: emptySet()
        if (sbn.packageName in blocked) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (sbn.isOngoing) return
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        var text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        if (!p.getBoolean("notif_text", true)) text = ""
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }
        BleService.instance?.sendNotification(label, title, text)
    }
}

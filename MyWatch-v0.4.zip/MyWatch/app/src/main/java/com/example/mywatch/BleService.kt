package com.example.mywatch

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.graphics.Bitmap
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleService : Service() {
    companion object {
        val state = MutableStateFlow(WatchState())
        val hrHistory = MutableStateFlow<List<Pair<Long, Int>>>(emptyList())
        val log = MutableStateFlow<List<String>>(emptyList())
        var instance: BleService? = null
        const val CCCD = "00002902-0000-1000-8000-00805f9b34fb"

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, BleService::class.java)) } catch (_: Exception) {}
        }

        fun addLog(s: String) {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            log.value = (log.value + "$t $s").takeLast(500)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val protocol: WatchProtocol = GenericProtocol()
    private var gatt: BluetoothGatt? = null
    private var curAddr: String? = null
    private var attempts = 0
    private val queue = ArrayDeque<() -> Boolean>()
    private var busy = false
    private var lastWeather: Pair<Int, Int>? = null
    private var connectingSince = 0L
    private var fgOk = false
    private val reconnectRunnable = Runnable { connect() }

    // لو البلوتوث اتقفل واتفتح: نرجع نتصل فورًا من غير ما نستنى المراقب.
    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_ON -> {
                    addLog("البلوتوث اتفتح، بنعيد الاتصال")
                    attempts = 0
                    main.removeCallbacks(reconnectRunnable)
                    gatt?.close(); gatt = null
                    queue.clear(); busy = false
                    if (addr() != null) connect()
                }
                BluetoothAdapter.STATE_OFF -> {
                    addLog("البلوتوث اتقفل")
                    main.removeCallbacks(reconnectRunnable)
                    gatt?.close(); gatt = null
                    queue.clear(); busy = false
                    upd { it.copy(status = "البلوتوث مقفول", connected = false) }
                }
            }
        }
    }

    private fun prefs() = getSharedPreferences("w", 0)
    private fun addr() = prefs().getString("addr", null)
    private fun upd(f: (WatchState) -> WatchState) { state.value = f(state.value) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val ch = NotificationChannel("ble", "اتصال الساعة", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        try {
            startForeground(1, Notification.Builder(this, "ble")
                .setContentTitle("MyWatch").setContentText("بيحافظ على اتصال الساعة")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).build())
            fgOk = true
        } catch (e: Exception) {
            // مفيش صلاحية بلوتوث (أو النظام منع التشغيل في الخلفية): منكملش عشان ما نعملش كراش.
            addLog("فشل تشغيل الخدمة: ${e.javaClass.simpleName}")
            stopSelf()
            return
        }
        try {
            ContextCompat.registerReceiver(this, btReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (_: Exception) {}
        // مراقب: لو المفروض متصلين وإحنا لأ، يعيد الاتصال. وكمان لو محاولة الاتصال علّقت أكتر من دقيقة.
        scope.launch {
            while (true) {
                delay(20_000)
                if (addr() == null || state.value.connected) continue
                if (gatt == null) connect()
                else if (System.currentTimeMillis() - connectingSince > 60_000) {
                    addLog("محاولة الاتصال علّقت، بنبدأ من جديد")
                    gatt?.close(); gatt = null
                    queue.clear(); busy = false
                    connect()
                }
            }
        }
        scope.launch(Dispatchers.IO) {
            while (true) {
                val ok = refreshWeather()
                delay(if (ok) 30 * 60_000L else 2 * 60_000L)
            }
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!fgOk) return START_NOT_STICKY
        attempts = 0; connect(); return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(btReceiver) } catch (_: Exception) {}
        main.removeCallbacksAndMessages(null)
        gatt?.close(); gatt = null
        scope.cancel(); super.onDestroy()
    }

    // ---------- الاتصال ----------
    fun connect() {
        val a = addr() ?: return
        main.removeCallbacks(reconnectRunnable)
        if (state.value.connected && gatt != null && curAddr == a) return
        // في محاولة اتصال شغالة من أقل من 30 ثانية: ما نقطعهاش.
        if (gatt != null && curAddr == a && System.currentTimeMillis() - connectingSince < 30_000) return
        try {
            val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
            if (adapter == null || !adapter.isEnabled) { upd { it.copy(status = "البلوتوث مقفول", connected = false) }; return }
            gatt?.close(); gatt = null
            curAddr = a
            upd { it.copy(status = "جاري الاتصال…", connected = false) }
            val dev = adapter.getRemoteDevice(a)
            upd { it.copy(deviceName = dev.name ?: a) }
            addLog("اتصال بـ $a (محاولة ${attempts + 1})")
            connectingSince = System.currentTimeMillis()
            gatt = dev.connectGatt(this, attempts > 0, cb, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            upd { it.copy(status = "محتاج صلاحية البلوتوث") }
        } catch (e: IllegalArgumentException) {
            upd { it.copy(status = "عنوان الساعة غير صحيح، اربطها من جديد") }
        }
    }

    fun forget() {
        prefs().edit().remove("addr").apply()
        main.removeCallbacks(reconnectRunnable)
        queue.clear(); busy = false
        gatt?.disconnect(); gatt?.close(); gatt = null; curAddr = null
        upd { WatchState() }
        hrHistory.value = emptyList()
    }

    private fun scheduleReconnect() {
        gatt?.close(); gatt = null
        queue.clear(); busy = false
        main.removeCallbacks(reconnectRunnable)
        if (addr() == null) return
        attempts++
        val ms = minOf(60_000L, 2_000L * (1L shl minOf(attempts, 5)))
        upd { it.copy(connected = false, status = "بيعيد الاتصال بعد ${ms / 1000} ث…") }
        main.postDelayed(reconnectRunnable, ms)
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                // نتجاهل أي نتيجة جاية من اتصال قديم اتقفل.
                if (g !== gatt) { try { g.close() } catch (_: Exception) {}; return@post }
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    upd { it.copy(status = "بيجهّز الاتصال…") }
                    g.discoverServices()
                } else {
                    addLog("انقطع الاتصال (status=$status)")
                    scheduleReconnect()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                if (g !== gatt) return@post
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    addLog("فشل اكتشاف الخدمات (status=$status)")
                    scheduleReconnect()
                    return@post
                }
                attempts = 0
                queue.clear(); busy = false
                upd { it.copy(connected = true, status = "متصلة", lastSync = System.currentTimeMillis()) }
                dumpServices(g)
                protocol.onReady(io)
                protocol.timeSync().forEach { io.write(it.first, it.second) }
                lastWeather?.let { sendWeather(it.first, it.second) }
                subscribeAndReadAll(g)
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
            main.post {
                if (g !== gatt) return@post
                if (st == 0) handle(c.uuid, c.value ?: ByteArray(0)) else addLog("فشل قراءة ${c.uuid} (status=$st)")
                next()
            }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            main.post { if (g === gatt) handle(c.uuid, c.value ?: ByteArray(0)) }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, v: ByteArray) {
            main.post { if (g === gatt) handle(c.uuid, v) }
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) { main.post { if (g === gatt) next() } }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) { main.post { if (g === gatt) next() } }
    }

    private fun handle(u: UUID, d: ByteArray) {
        addLog("← ${u.toString().take(8)} ${d.hex()}")
        val old = state.value
        val nw = protocol.onData(u, d, old).copy(lastSync = System.currentTimeMillis())
        state.value = nw
        val h = nw.hr
        if (h != null && h != old.hr) hrHistory.value = (hrHistory.value + (System.currentTimeMillis() to h)).takeLast(300)
    }

    // ---------- تشخيص ----------
    private fun props(c: BluetoothGattCharacteristic): String {
        val p = c.properties
        val sb = StringBuilder()
        if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0) sb.append("R")
        if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) sb.append("W")
        if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) sb.append("w")
        if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) sb.append("N")
        if ((p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) sb.append("I")
        return sb.toString()
    }

    private fun dumpServices(g: BluetoothGatt) {
        addLog("=== خدمات الساعة ===")
        for (s in g.services) {
            addLog("S ${s.uuid}")
            for (c in s.characteristics) addLog("   C ${c.uuid} [${props(c)}]")
        }
    }

    private fun subscribeAndReadAll(g: BluetoothGatt) {
        for (s in g.services) for (c in s.characteristics) {
            val p = c.properties
            if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 || (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)
                enqueue { subscribeChar(c) }
            if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0)
                enqueue { gatt?.readCharacteristic(c) ?: false }
        }
    }

    // ---------- طابور عمليات GATT ----------
    private fun enqueue(op: () -> Boolean) { queue.add(op); if (!busy) next() }
    private fun next() {
        val op = queue.removeFirstOrNull()
        if (op == null) { busy = false; return }
        busy = true
        if (!op()) next()
    }

    private fun find(u: UUID): BluetoothGattCharacteristic? =
        gatt?.services?.flatMap { it.characteristics }?.firstOrNull { it.uuid == u }

    private fun subscribeChar(c: BluetoothGattCharacteristic): Boolean {
        val g = gatt ?: return false
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(UUID.fromString(CCCD)) ?: return false
        d.value = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        return g.writeDescriptor(d)
    }

    private fun writeChar(c: BluetoothGattCharacteristic, data: ByteArray): Boolean {
        val g = gatt ?: return false
        c.writeType = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        c.value = data
        addLog("→ ${c.uuid.toString().take(8)} ${data.hex()}")
        return g.writeCharacteristic(c)
    }

    private val io = object : Io {
        override fun write(char: UUID, data: ByteArray) { enqueue { val c = find(char); if (c == null) false else writeChar(c, data) } }
        override fun read(char: UUID) { enqueue { val c = find(char); if (c == null) false else (gatt?.readCharacteristic(c) ?: false) } }
        override fun subscribe(char: UUID) { enqueue { val c = find(char); if (c == null) false else subscribeChar(c) } }
    }

    // ---------- أوامر من الواجهة ----------
    private fun send(p: Packets): Boolean {
        if (p.isEmpty() || !state.value.connected) return false
        p.forEach { io.write(it.first, it.second) }
        return true
    }

    fun syncTime(): Boolean = send(protocol.timeSync())
    fun setAlarm(h: Int, m: Int, on: Boolean): Boolean = send(protocol.setAlarm(h, m, on))
    fun measure(kind: String): Boolean = send(protocol.measure(kind))

    /** تحويل الـ Bitmap لـ RGB565 وتسليمه للبروتوكول. */
    fun setWatchFace(bmp: Bitmap): Boolean {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 2)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
            val v = ((r shr 3) shl 11) or ((g shr 2) shl 5) or (b shr 3)
            out[2 * i] = (v and 0xFF).toByte()
            out[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return send(protocol.watchFace(w, h, out))
    }

    /** إرسال بايتات خام لخاصية معينة (للتجربة وفك البروتوكول). */
    fun sendRaw(uuidText: String, hexText: String): String {
        if (!state.value.connected) return "الساعة غير متصلة"
        val u = try {
            val t = uuidText.trim()
            if (t.length <= 4) u16(t.toInt(16)) else UUID.fromString(t)
        } catch (e: Exception) { return "UUID غير صحيح" }
        val bytes = try {
            hexText.replace(" ", "").chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (e: Exception) { return "الـ HEX غير صحيح" }
        if (bytes.isEmpty()) return "اكتب HEX"
        val c = find(u) ?: return "الخاصية دي مش موجودة في الساعة"
        enqueue { writeChar(c, bytes) }
        return "اتبعت"
    }

    // ---------- الإشعارات والطقس ----------
    fun sendNotification(app: String, title: String, text: String) {
        addLog("إشعار: $app | $title")
        if (!state.value.connected) { addLog("   (الساعة غير متصلة)"); return }
        val p = protocol.notification(app, title, text)
        if (p.isEmpty()) { addLog("   (إرسال الإشعارات لسه مش متعرّف للساعة دي)"); return }
        send(p)
    }

    private fun sendWeather(t: Int, code: Int) { send(protocol.weather(t, code)) }

    private suspend fun refreshWeather(): Boolean {
        try {
            val p = prefs()
            if (!p.getBoolean("weather_on", true)) return true
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc = listOf("fused", "network", "passive", "gps").mapNotNull {
                try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
            }.maxByOrNull { it.time }
            if (loc != null) p.edit().putFloat("lat", loc.latitude.toFloat()).putFloat("lon", loc.longitude.toFloat()).apply()
            val lat = p.getFloat("lat", Float.NaN); val lon = p.getFloat("lon", Float.NaN)
            if (lat.isNaN() || lon.isNaN()) return false
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000; c.readTimeout = 10_000
            val cur = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("current")
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val code = cur.getInt("weather_code")
            withContext(Dispatchers.Main) {
                lastWeather = t to code
                upd { it.copy(weatherC = t, weatherCode = code) }
                if (state.value.connected) sendWeather(t, code)
            }
            c.disconnect()
            return true
        } catch (_: Exception) { /* أوفلاين: بنسيب آخر قيمة */ return false }
    }
}

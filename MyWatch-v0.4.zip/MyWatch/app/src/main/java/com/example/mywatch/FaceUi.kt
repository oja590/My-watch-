package com.example.mywatch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import java.util.Calendar

/** إعدادات شكل الساعة المحفوظة. 0 في الألوان = اللون الافتراضي للتصميم. */
class FacePrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("w", 0)
    var id: Int
        get() = p.getInt("face_id", 0).coerceIn(0, FACE_DESIGNS.size - 1)
        set(v) { p.edit().putInt("face_id", v).apply() }
    var accent: Int
        get() = p.getInt("face_accent", 0)
        set(v) { p.edit().putInt("face_accent", v).apply() }
    var bg: Int
        get() = p.getInt("face_bg", 0)
        set(v) { p.edit().putInt("face_bg", v).apply() }
    var showDate: Boolean
        get() = p.getBoolean("face_date", true)
        set(v) { p.edit().putBoolean("face_date", v).apply() }
    /** مقاس شاشة الساعة بالبكسل. هيتظبط على مقاس ESW07 الحقيقي بعد فك البروتوكول. */
    var w: Int
        get() = p.getInt("face_w", 240)
        set(v) { p.edit().putInt("face_w", v).apply() }
    var h: Int
        get() = p.getInt("face_h", 240)
        set(v) { p.edit().putInt("face_h", v).apply() }
}

private fun faceImageFile(ctx: Context) = File(ctx.filesDir, "face_bg.png")

fun loadFaceImage(ctx: Context): Bitmap? = try {
    val f = faceImageFile(ctx)
    if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
} catch (e: Exception) { null }

fun importFaceImage(ctx: Context, uri: Uri): Boolean {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1000 || bounds.outHeight / sample > 1000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
        faceImageFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    } catch (e: Exception) { false }
}

@Composable
fun SwatchRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        item {
            Text(
                "افتراضي", color = if (selected == 0) C.green else C.dim, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, if (selected == 0) C.green else C.dim, RoundedCornerShape(50))
                    .clickable { onPick(0) }.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
        items(colors) { c ->
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (selected == c) 3.dp else 1.dp, if (selected == c) C.green else C.dim, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun FaceScreen(s: WatchState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val fp = remember { FacePrefs(ctx) }
    var id by remember { mutableStateOf(fp.id) }
    var accent by remember { mutableStateOf(fp.accent) }
    var bg by remember { mutableStateOf(fp.bg) }
    var showDate by remember { mutableStateOf(fp.showDate) }
    var imgVer by remember { mutableStateOf(0) }
    val bgImage = remember(imgVer) { loadFaceImage(ctx) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (importFaceImage(ctx, uri)) imgVer++ else toast(ctx, "ماقدرتش أقرا الصورة دي")
        }
    }
    val minute by produceState(initialValue = System.currentTimeMillis() / 60000) {
        while (true) { value = System.currentTimeMillis() / 60000; delay(5_000) }
    }

    val design = FACE_DESIGNS[id]
    val big = remember(id, accent, bg, showDate, bgImage, minute) {
        renderFace(design, accent.takeIf { it != 0 }, bg.takeIf { it != 0 }, bgImage, showDate, fp.w, fp.h).asImageBitmap()
    }

    DetailScaffold("شكل الساعة", onBack) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Image(
                bitmap = big, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(220.dp).aspectRatio(fp.w / fp.h.toFloat())
                    .clip(RoundedCornerShape(36.dp)).border(3.dp, C.card, RoundedCornerShape(36.dp))
            )
        }
        Text(design.name, color = C.text, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())

        SectionCard("التصميمات (${FACE_DESIGNS.size})") {
            val thumbCal = remember { Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 10); set(Calendar.MINUTE, 10) } }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(FACE_DESIGNS) { d ->
                    val th = remember(d.id, accent, bg, showDate, bgImage) {
                        renderFace(d, accent.takeIf { it != 0 }, bg.takeIf { it != 0 }, bgImage, showDate, 120, (120 * fp.h / fp.w.toFloat()).toInt(), thumbCal).asImageBitmap()
                    }
                    Image(
                        bitmap = th, contentDescription = d.name,
                        modifier = Modifier.width(84.dp).aspectRatio(fp.w / fp.h.toFloat()).clip(RoundedCornerShape(16.dp))
                            .border(if (d.id == id) 3.dp else 1.dp, if (d.id == id) C.green else C.card, RoundedCornerShape(16.dp))
                            .clickable { id = d.id; fp.id = d.id }
                    )
                }
            }
        }

        SectionCard("لون التمييز") {
            SwatchRow(ACCENT_CHOICES, accent) { accent = it; fp.accent = it }
        }
        SectionCard("لون الخلفية") {
            SwatchRow(BG_CHOICES, bg) { bg = it; fp.bg = it }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch("image/*") }) { Text("🖼️ اختيار صورة خلفية") }
                if (bgImage != null) OutlinedButton(onClick = {
                    faceImageFile(ctx).delete(); imgVer++
                }) { Text("إزالة الصورة") }
            }
            Text("الصورة بتتقص تلقائي على مقاس الساعة وبيتحط عليها تعتيم خفيف عشان الوقت يبان.", color = C.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        SectionCard("إعدادات") {
            SwitchRowLocal("إظهار التاريخ", showDate) { showDate = it; fp.showDate = it }
        }

        Button(onClick = {
            val bmp = renderFace(design, accent.takeIf { it != 0 }, bg.takeIf { it != 0 }, bgImage, showDate, fp.w, fp.h)
            val ok = BleService.instance?.setWatchFace(bmp) == true
            toast(ctx, if (ok) "اتبعت الواجهة للساعة" else "الواجهة اتحفظت في التطبيق. إرسالها للساعة لسه مش متعرّف (محتاج فك بروتوكول ESW07)")
        }, modifier = Modifier.fillMaxWidth()) { Text("تطبيق على الساعة") }
        NoteCard("المعاينة بتتحدّث لوحدها. مقاس الصورة الحالي ${fp.w}×${fp.h} بكسل، وهيتظبط على مقاس شاشة ESW07 بعد ما نعرفه من سجل التشخيص.")
    }
}

@Composable
private fun SwitchRowLocal(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = C.text, modifier = Modifier.weight(1f))
        androidx.compose.material3.Switch(checked = on, onCheckedChange = onChange)
    }
}

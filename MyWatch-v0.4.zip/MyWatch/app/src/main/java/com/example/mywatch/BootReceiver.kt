package com.example.mywatch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.getSharedPreferences("w", 0).getString("addr", null) == null) return
        // على أندرويد 12+ الصلاحية لازم تكون موجودة وإلا الخدمة هتقع.
        if (hasBtPermission(c)) BleService.start(c)
    }
}

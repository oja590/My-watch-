package com.example.mywatch

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object C {
    val bg = Color(0xFF0E1116)
    val card = Color(0xFF1A1F27)
    val green = Color(0xFF22C55E)
    val red = Color(0xFFFF4D6D)
    val purple = Color(0xFF8B5CF6)
    val blue = Color(0xFF38BDF8)
    val orange = Color(0xFFFB923C)
    val yellow = Color(0xFFFACC15)
    val teal = Color(0xFF2DD4BF)
    val text = Color(0xFFF1F5F9)
    val dim = Color(0xFF94A3B8)
}

const val STEP_GOAL = 10000
const val SLEEP_GOAL_H = 8
const val TRUTH_NOTE = "القراءة دي بتتعرض زي ما الساعة بتبعتها بالظبط، من غير أي تعديل أو تقدير من التطبيق."
const val ESTIMATE_NOTE = " حساسات الساعات دي تقريبية وليست للاستخدام الطبي."

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
fun timeNow(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
fun timeOf(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

fun stressLabel(v: Int?): String = when {
    v == null -> ""
    v < 24 -> "استرخاء"
    v < 48 -> "طبيعي"
    v < 72 -> "متوسط"
    else -> "مرتفع"
}

fun fmtPace(sec: Int?): String = if (sec == null) "—" else String.format(Locale.US, "%d'%02d/كم", sec / 60, sec % 60)

fun weatherDesc(c: Int?): String {
    if (c == null) return "—"
    return when (c) {
        0 -> "صافي"
        1, 2 -> "غائم جزئياً"
        3 -> "غائم"
        45, 48 -> "ضباب"
        in 51..57 -> "رذاذ"
        in 61..67 -> "مطر"
        in 71..77 -> "ثلج"
        in 80..82 -> "زخات مطر"
        in 95..99 -> "عاصفة رعدية"
        else -> "—"
    }
}

fun weatherEmoji(c: Int?): String {
    if (c == null) return "⛅"
    return when (c) {
        0 -> "☀️"
        1, 2 -> "🌤️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67, in 80..82 -> "🌧️"
        in 71..77 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "⛅"
    }
}

// ---------- بيانات الكروت ----------
data class Metric(val key: String, val emoji: String, val title: String, val value: String?, val unit: String, val color: Color, val note: String)

fun metricsOf(s: WatchState): List<Metric> = listOf(
    Metric("hr", "❤️", "النبض", s.hr?.toString(), "نبضة/د", C.red, TRUTH_NOTE),
    Metric("spo2", "🫁", "الأكسجين", s.spo2?.toString(), "%", C.blue, TRUTH_NOTE + ESTIMATE_NOTE),
    Metric("bp", "🩸", "ضغط الدم", if (s.sys != null && s.dia != null) "${s.sys}/${s.dia}" else null, "mmHg", C.orange, TRUTH_NOTE + ESTIMATE_NOTE),
    Metric("temp", "🌡️", "الحرارة", s.temp?.let { String.format(Locale.US, "%.1f", it) }, "°C", C.yellow, TRUTH_NOTE + ESTIMATE_NOTE),
    Metric("water", "💧", "الماء في الجسم", s.water?.toString(), "%", C.teal, TRUTH_NOTE + ESTIMATE_NOTE),
    Metric("sleep", "😴", "النوم", s.sleepMin?.let { "${it / 60}س ${it % 60}د" }, "", C.purple, TRUTH_NOTE),
    Metric("stress", "🧘", "الضغط النفسي", s.stress?.toString(), stressLabel(s.stress), C.teal, TRUTH_NOTE + ESTIMATE_NOTE),
    Metric("workout", "⌚", "حركة الساعة", s.workoutMin?.let { "${it / 60}س ${it % 60}د" }, "", C.purple, TRUTH_NOTE),
    Metric("run", "📍", "الجري GPS", s.runM?.let { String.format(Locale.US, "%.2f", it / 1000f) }, "كم", C.green, TRUTH_NOTE),
    Metric("battery", "🔋", "بطارية الساعة", s.battery?.toString(), "%", C.green, TRUTH_NOTE),
    Metric("weather", weatherEmoji(s.weatherCode), "الطقس", s.weatherC?.let { "$it°" }, weatherDesc(s.weatherCode), C.blue,
        "الطقس بييجي من الإنترنت حسب موقع الموبايل، مش من الساعة. وبنبعته للساعة كل نص ساعة لما تدعم الميزة دي."),
    Metric("time", "⏰", "الوقت والمنبه", timeNow(), "", C.green, "الوقت هنا وقت الموبايل. زرار الضبط بيبعته للساعة."),
    Metric("steps", "👟", "الخطوات", s.steps?.toString(), "خطوة", C.green, TRUTH_NOTE)
)

// ---------- أدوات واجهة ----------
private val shownCards = HashSet<String>()
@Composable
fun Pulse(min: Float, max: Float, ms: Int = 1000): Float {
    val t = rememberInfiniteTransition(label = "pulse")
    val v by t.animateFloat(min, max, infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pv")
    return v
}

@Composable
fun Ring(progress: Float, color: Color, diameter: Dp, stroke: Dp, content: @Composable BoxScope.() -> Unit) {
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(progress) { target = progress.coerceIn(0f, 1f) }
    val p by animateFloatAsState(target, tween(900), label = "ring")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(this.size.width - sw, this.size.height - sw)
            drawArc(color.copy(alpha = 0.18f), -90f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * p, false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun MetricCard(m: Metric, idx: Int, dim: Boolean, modifier: Modifier, onClick: () -> Unit) {
    // الأنيميشن يشتغل مرة واحدة بس لكل كارت، مش كل ما نعمل scroll ونرجع.
    var shown by remember { mutableStateOf(m.key in shownCards) }
    LaunchedEffect(Unit) { if (!shown) { delay(idx * 70L); shown = true; shownCards.add(m.key) } }
    AnimatedVisibility(
        visible = shown, modifier = modifier,
        enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 5 }
    ) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card)
                .clickable(onClick = onClick).padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.emoji, fontSize = 20.sp)
                Spacer(Modifier.width(8.dp))
                Text(m.title, color = C.dim, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                val v = m.value
                Text(
                    v ?: "—", fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    color = if (v == null) C.dim else if (dim) m.color.copy(alpha = 0.55f) else m.color
                )
                if (v != null && m.unit.isNotEmpty()) {
                    Spacer(Modifier.width(4.dp))
                    Text(m.unit, color = C.dim, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
            }
        }
    }
}

@Composable
fun DetailScaffold(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("→", fontSize = 26.sp, color = C.text, modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(10.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.text)
        }
        content()
    }
}

@Composable
fun Hero(emoji: String, color: Color, value: String?, unit: String, pulse: Boolean) {
    val sc = if (pulse) Pulse(0.9f, 1.1f, 700) else 1f
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.card).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 56.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value ?: "—", fontSize = 52.sp, fontWeight = FontWeight.Bold, color = if (value == null) C.dim else color)
            if (value != null && unit.isNotEmpty()) {
                Spacer(Modifier.width(6.dp))
                Text(unit, color = C.dim, fontSize = 16.sp, modifier = Modifier.padding(bottom = 10.dp))
            }
        }
    }
}

@Composable
fun NoteCard(text: String) {
    Text(text, color = C.dim, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.card).padding(14.dp))
}

@Composable
fun StatusLine(s: WatchState) {
    val t = when {
        s.lastSync == 0L -> "لسه مفيش أي بيانات جت من الساعة."
        s.connected -> "الساعة متصلة. آخر بيانات: ${timeOf(s.lastSync)}"
        else -> "الساعة غير متصلة. آخر بيانات وصلت: ${timeOf(s.lastSync)}"
    }
    Text(t, color = if (s.connected) C.green else C.red, fontSize = 13.sp)
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card).padding(16.dp)) {
        Text(title, color = C.green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, key: String, def: Boolean) {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("w", 0) }
    var on by remember { mutableStateOf(p.getBoolean(key, def)) }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.text)
            if (sub != null) Text(sub, color = C.dim, fontSize = 12.sp)
        }
        Switch(checked = on, onCheckedChange = { on = it; p.edit().putBoolean(key, it).apply() })
    }
}

@Composable
fun ActionRow(text: String, onClick: () -> Unit) {
    Text(text, color = C.text, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp))
}

// ---------- التطبيق ----------
@Composable
fun App() {
    val ctx = LocalContext.current
    val perms = buildList {
        if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_CONNECT) }
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (ctx.getSharedPreferences("w", 0).getString("addr", null) != null && hasBtPermission(ctx)) BleService.start(ctx)
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }

    var screen by remember { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = if (screen == "apps") "settings" else "home" }
    val s by BleService.state.collectAsStateWithLifecycle()

    AnimatedContent(
        targetState = screen,
        transitionSpec = { (fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 12 }) togetherWith fadeOut(tween(150)) },
        label = "nav"
    ) { sc ->
        when (sc) {
            "home" -> Home(s) { screen = it }
            "settings" -> SettingsScreen(s, onBack = { screen = "home" }, go = { screen = it })
            "apps" -> AppsScreen { screen = "settings" }
            "devices" -> DevicesScreen { screen = "home" }
            "diag" -> DiagScreen(s) { screen = "home" }
            "face" -> FaceScreen(s) { screen = "home" }
            else -> DetailScreen(sc, s) { screen = "home" }
        }
    }
}

// ---------- الرئيسية ----------
@Composable
fun Home(s: WatchState, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val hasDevice = ctx.getSharedPreferences("w", 0).getString("addr", null) != null
    val now by produceState(initialValue = timeNow()) { while (true) { value = timeNow(); delay(10_000) } }
    // الحرارة والماء مش موجودين في كل الساعات: نخفيهم لحد ما الساعة تبعتهم فعلًا.
    val metrics = metricsOf(s).filter { it.key != "steps" && !(it.key in listOf("temp", "water") && it.value == null) }.map { if (it.key == "time") it.copy(value = now) else it } +
        Metric("face", "🎨", "شكل الساعة", null, "", C.purple, "") +
        Metric("diag", "🧪", "التشخيص", null, "", C.dim, "")
    val dim = !s.connected

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.deviceName ?: "ساعتي", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = C.text)
                    Spacer(Modifier.height(6.dp))
                    val a = if (s.connected) Pulse(0.35f, 1f, 900) else 1f
                    val col = if (s.connected) C.green else C.red
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = 0.15f)).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(col.copy(alpha = a)))
                        Spacer(Modifier.width(8.dp))
                        Text(s.status, color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        if (s.battery != null) { Spacer(Modifier.width(10.dp)); Text("🔋 ${s.battery}%", color = C.text, fontSize = 13.sp) }
                    }
                    if (s.lastSync > 0) Text("آخر بيانات: ${timeOf(s.lastSync)}", color = C.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Text("⚙️", fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { go("settings") }.padding(10.dp))
            }
        }
        if (!hasDevice) item {
            Button(onClick = { go("devices") }, modifier = Modifier.fillMaxWidth()) { Text("ربط ساعة جديدة") }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(C.card).clickable { go("steps") }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ring((s.steps ?: 0) / STEP_GOAL.toFloat(), C.green, 120.dp, 12.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("👟", fontSize = 20.sp)
                        Text(s.steps?.toString() ?: "—", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (s.steps == null) C.dim else C.green)
                    }
                }
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("الخطوات", color = C.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("الهدف: $STEP_GOAL", color = C.dim, fontSize = 13.sp)
                    Text("المسافة: ${s.distanceM?.let { String.format(Locale.US, "%.2f كم", it / 1000f) } ?: "—"}", color = C.dim, fontSize = 13.sp)
                    Text("السعرات: ${s.calories?.toString() ?: "—"}", color = C.dim, fontSize = 13.sp)
                    Text("النشاط: ${s.activeMin?.toString() ?: "—"} دقيقة", color = C.dim, fontSize = 13.sp)
                }
            }
        }
        itemsIndexed(metrics.chunked(2)) { row, pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEachIndexed { i, m ->
                    MetricCard(m, row * 2 + i + 1, dim, Modifier.weight(1f)) { go(if (m.key == "diag") "diag" else m.key) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ---------- التفاصيل ----------
@Composable
fun DetailScreen(key: String, s: WatchState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val m = metricsOf(s).firstOrNull { it.key == key } ?: run { onBack(); return }
    DetailScaffold(m.title, onBack) {
        val v = if (key == "time") timeNow() else m.value
        Hero(m.emoji, m.color, v, m.unit, pulse = key == "hr" && s.connected)
        StatusLine(s)
        when (key) {
            "hr" -> {
                RangeBar(s.hr?.toFloat(), 50f, 160f, listOf("إحماء واسترخاء", "حرق الدهون", "تقوية القلب والرئة", "تحمّل أعلى", "الحد الأقصى"), C.red)
                HrChart()
            }
            "spo2" -> RangeBar(s.spo2?.toFloat(), 80f, 100f, listOf("80", "85", "90", "95", "100"), C.blue)
            "bp" -> RangeBar(s.sys?.toFloat(), 0f, 200f, listOf("0", "50", "100", "150", "200"), C.orange)
            "stress" -> RangeBar(s.stress?.toFloat(), 0f, 100f, listOf("استرخاء", "طبيعي", "متوسط", "مرتفع"), C.teal)
            "sleep" -> {
                val pct = (((s.sleepMin ?: 0) * 100f) / (SLEEP_GOAL_H * 60)).toInt()
                Ring((s.sleepMin ?: 0) / (SLEEP_GOAL_H * 60f), C.purple, 180.dp, 16.dp) {
                    Text("$pct%", fontSize = 28.sp, color = C.purple, fontWeight = FontWeight.Bold)
                }
                Text("الهدف: $SLEEP_GOAL_H ساعات", color = C.dim)
            }
            "workout" -> {
                Text("متوسط النبض: ${s.workoutHr?.toString() ?: "—"} نبضة/د", color = C.text)
                Text("السعرات: ${s.workoutCal?.toString() ?: "—"} ك.ك", color = C.text)
            }
            "run" -> {
                Text("الوقت: ${s.runMin?.let { "${it / 60}س ${it % 60}د" } ?: "—"}", color = C.text)
                Text("السرعة (pace): ${fmtPace(s.runPaceSec)}", color = C.text)
                Text("السعرات: ${s.runCal?.toString() ?: "—"} ك.ك", color = C.text)
            }
            "steps" -> {
                Ring((s.steps ?: 0) / STEP_GOAL.toFloat(), C.green, 180.dp, 16.dp) {
                    Text("${(((s.steps ?: 0) * 100f) / STEP_GOAL).toInt()}%", fontSize = 28.sp, color = C.green, fontWeight = FontWeight.Bold)
                }
                Text("الهدف اليومي: $STEP_GOAL خطوة", color = C.dim)
                Text("المسافة: ${s.distanceM?.let { String.format(Locale.US, "%.2f كم", it / 1000f) } ?: "—"}", color = C.text)
                Text("السعرات: ${s.calories?.toString() ?: "—"}", color = C.text)
                Text("دقائق النشاط: ${s.activeMin?.toString() ?: "—"}", color = C.text)
            }
            "weather" -> Text(weatherDesc(s.weatherCode), color = C.text, fontSize = 18.sp)
            "time" -> TimeExtra()
        }
        if (key in listOf("hr", "spo2", "bp", "temp", "water", "stress")) {
            Button(onClick = {
                val ok = BleService.instance?.measure(key) == true
                toast(ctx, if (ok) "اتبعت أمر القياس للساعة" else "أمر القياس لسه مش متعرّف للساعة دي، هنفعّله بعد فك البروتوكول")
            }, modifier = Modifier.fillMaxWidth()) { Text("قياس الآن") }
        }
        NoteCard(m.note)
    }
}

/** شريط مدى بعلامة مكان القراءة الحالية (زي أشرطة تطبيق الساعة الأصلي). */
@Composable
fun RangeBar(value: Float?, min: Float, max: Float, labels: List<String>, color: Color) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card).padding(14.dp)) {
        Canvas(Modifier.fillMaxWidth().height(22.dp)) {
            val r = 9.dp.toPx()
            val y = size.height / 2
            drawLine(color.copy(alpha = 0.25f), Offset(r, y), Offset(size.width - r, y), strokeWidth = 14.dp.toPx(), cap = StrokeCap.Round)
            if (value != null) {
                val f = ((value - min) / (max - min)).coerceIn(0f, 1f)
                drawCircle(color, r, Offset(r + f * (size.width - 2 * r), y))
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            labels.forEach { Text(it, color = C.dim, fontSize = 11.sp) }
        }
    }
}

@Composable
fun HrChart() {
    val h by BleService.hrHistory.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.card).padding(14.dp)) {
        Text("قراءات النبض اللي وصلت من الساعة", color = C.dim, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        if (h.size < 2) {
            Text("لسه مفيش قراءات كفاية للرسم.", color = C.dim, fontSize = 13.sp)
        } else {
            val vals = h.map { it.second }
            val lo = vals.min(); val hi = vals.max()
            Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                val path = Path()
                val span = (hi - lo).coerceAtLeast(1).toFloat()
                vals.forEachIndexed { i, v ->
                    val x = size.width * i / (vals.size - 1).toFloat()
                    val y = size.height - (v - lo) / span * size.height * 0.9f - size.height * 0.05f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, C.red, style = Stroke(4f, cap = StrokeCap.Round))
            }
            Text("أقل: $lo   أعلى: $hi   عدد القراءات: ${vals.size}", color = C.text, fontSize = 13.sp)
        }
    }
}

data class Alarm(val h: Int, val m: Int, val on: Boolean)

fun loadAlarms(p: SharedPreferences): List<Alarm> =
    (p.getStringSet("alarms", emptySet()) ?: emptySet()).mapNotNull {
        val x = it.split(":")
        if (x.size == 3) Alarm(x[0].toInt(), x[1].toInt(), x[2] == "1") else null
    }.sortedBy { it.h * 60 + it.m }

fun saveAlarms(p: SharedPreferences, l: List<Alarm>) {
    p.edit().putStringSet("alarms", l.map { "${it.h}:${it.m}:${if (it.on) 1 else 0}" }.toSet()).apply()
}

@Composable
fun TimeExtra() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("w", 0) }
    var alarms by remember { mutableStateOf(loadAlarms(p)) }
    var adding by remember { mutableStateOf(false) }

    fun push(a: Alarm) {
        val ok = BleService.instance?.setAlarm(a.h, a.m, a.on) == true
        toast(ctx, if (ok) "اتبعت المنبه للساعة" else "المنبه اتحفظ في التطبيق، لكن إرساله للساعة لسه مش متعرّف (هنفعّله بعد فك البروتوكول)")
    }

    Button(onClick = {
        val ok = BleService.instance?.syncTime() == true
        toast(ctx, if (ok) "اتضبط وقت الساعة" else "ضبط الوقت لسه مش متعرّف للساعة دي، أو الساعة غير متصلة")
    }, modifier = Modifier.fillMaxWidth()) { Text("ظبّط وقت الساعة بوقت الموبايل") }

    SectionCard("المنبهات") {
        if (alarms.isEmpty()) Text("مفيش منبهات.", color = C.dim)
        alarms.forEach { a ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(String.format(Locale.US, "%02d:%02d", a.h, a.m), fontSize = 26.sp, color = if (a.on) C.text else C.dim, modifier = Modifier.weight(1f))
                Switch(checked = a.on, onCheckedChange = { v ->
                    val n = a.copy(on = v)
                    alarms = (alarms - a + n).sortedBy { it.h * 60 + it.m }; saveAlarms(p, alarms); push(n)
                })
                TextButton(onClick = { alarms = alarms - a; saveAlarms(p, alarms); push(a.copy(on = false)) }) { Text("حذف", color = C.red) }
            }
        }
        OutlinedButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة منبه") }
    }

    if (adding) {
        var h by remember { mutableStateOf(7) }
        var mi by remember { mutableStateOf(0) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("منبه جديد") },
            text = {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    Stepper(h, 0, 23) { h = it }
                    Text(":", fontSize = 28.sp)
                    Stepper(mi, 0, 59) { mi = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val a = Alarm(h, mi, true)
                    alarms = (alarms + a).sortedBy { it.h * 60 + it.m }; saveAlarms(p, alarms); adding = false; push(a)
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun Stepper(value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("▲", fontSize = 24.sp, modifier = Modifier.clickable { onChange(if (value >= max) min else value + 1) }.padding(8.dp))
        Text(String.format(Locale.US, "%02d", value), fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("▼", fontSize = 24.sp, modifier = Modifier.clickable { onChange(if (value <= min) max else value - 1) }.padding(8.dp))
    }
}

// ---------- الإعدادات ----------
@Composable
fun SettingsScreen(s: WatchState, onBack: () -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    DetailScaffold("مركز الإعدادات", onBack) {
        SectionCard("الساعة") {
            Text("${s.deviceName ?: "مفيش ساعة مربوطة"} — ${s.status}", color = C.text)
            ActionRow("🔄 إعادة الاتصال") { BleService.start(ctx) }
            ActionRow("🔍 البحث عن ساعة وربطها") { go("devices") }
            ActionRow("🎨 شكل الساعة وخلفيتها") { go("face") }
            ActionRow("🗑️ إلغاء ربط الساعة") {
                BleService.instance?.forget() ?: ctx.getSharedPreferences("w", 0).edit().remove("addr").apply()
                toast(ctx, "اتلغى الربط")
            }
        }
        SectionCard("الإشعارات للساعة") {
            SwitchRow("إرسال الإشعارات للساعة", "كل إشعارات الموبايل ما عدا اللي تقفلها من القايمة", "notif_enabled", true)
            SwitchRow("إظهار نص الرسالة", "لو مقفول هيتبعت اسم التطبيق والعنوان بس", "notif_text", true)
            ActionRow("📱 اختيار التطبيقات") { go("apps") }
            ActionRow("🔑 إذن قراءة الإشعارات") { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
        SectionCard("الطقس") {
            SwitchRow("تحديث الطقس وإرساله للساعة", "من الإنترنت حسب موقع الموبايل", "weather_on", true)
        }
        SectionCard("الاستمرار في الخلفية") {
            Text("عشان الساعة تفضل متصلة، اسمح للتطبيق يشتغل في الخلفية من غير قيود بطارية.", color = C.dim, fontSize = 13.sp)
            ActionRow("✅ استثناء التطبيق من توفير البطارية") {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isIgnoringBatteryOptimizations(ctx.packageName)) toast(ctx, "التطبيق مستثنى بالفعل")
                else try {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            Text("على أجهزة شاومي/أوبو/ريلمي/سامسونج: فعّل كمان \"التشغيل التلقائي\" وخلّي التطبيق \"بدون قيود\" من إعدادات التطبيق.", color = C.dim, fontSize = 12.sp)
        }
        SectionCard("متقدم") { ActionRow("🧪 شاشة التشخيص") { go("diag") } }
    }
}

data class AppItem(val label: String, val pkg: String)

@Composable
fun AppsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("w", 0) }
    var blocked by remember { mutableStateOf(HashSet(p.getStringSet("blocked", emptySet()) ?: emptySet())) }
    val apps by produceState(initialValue = emptyList<AppItem>()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0).map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("→", fontSize = 26.sp, color = C.text, modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(10.dp))
            Spacer(Modifier.width(8.dp))
            Text("التطبيقات اللي إشعاراتها توصل للساعة", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.text)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(apps) { a ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(a.label, color = C.text, modifier = Modifier.weight(1f))
                    Switch(checked = a.pkg !in blocked, onCheckedChange = { on ->
                        val n = HashSet(blocked)
                        if (on) n.remove(a.pkg) else n.add(a.pkg)
                        blocked = n
                        p.edit().putStringSet("blocked", n).apply()
                    })
                }
            }
        }
    }
}

// ---------- الأجهزة ----------
data class Found(val dev: BluetoothDevice, val rssi: Int)

@SuppressLint("MissingPermission")
@Composable
fun DevicesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val found = remember { mutableStateListOf<Found>() }
    val cb = remember {
        object : ScanCallback() {
            override fun onScanResult(t: Int, r: ScanResult) {
                val f = Found(r.device, r.rssi)
                val i = found.indexOfFirst { it.dev.address == r.device.address }
                if (i >= 0) found[i] = f else found.add(f)
            }
        }
    }
    DisposableEffect(Unit) {
        val sc = try { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bluetoothLeScanner } catch (e: Exception) { null }
        try { sc?.startScan(cb) } catch (e: SecurityException) { }
        onDispose { try { sc?.stopScan(cb) } catch (e: SecurityException) { } }
    }
    fun nameOf(d: BluetoothDevice): String? = try { d.name } catch (e: SecurityException) { null }

    DetailScaffold("ربط ساعة", onBack) {
        Text("قرّب الساعة من الموبايل وافصلها من أي تطبيق تاني. بيتم البحث تلقائياً.", color = C.dim, fontSize = 13.sp)
        found.sortedWith(compareBy<Found> { nameOf(it.dev) == null }.thenByDescending { it.rssi }).forEach { f ->
            val n = nameOf(f.dev)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.card).clickable {
                    ctx.getSharedPreferences("w", 0).edit().putString("addr", f.dev.address).apply()
                    BleService.start(ctx)
                    onBack()
                }.padding(14.dp)
            ) {
                Text(n ?: "جهاز بدون اسم", color = if (n == null) C.dim else C.text, fontWeight = FontWeight.Bold)
                Text("${f.dev.address}   الإشارة: ${f.rssi}", color = C.dim, fontSize = 12.sp)
            }
        }
    }
}

// ---------- التشخيص ----------
@Composable
fun DiagScreen(s: WatchState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lines by BleService.log.collectAsStateWithLifecycle()
    var uuid by remember { mutableStateOf("") }
    var hex by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("→", fontSize = 26.sp, color = C.text, modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(10.dp))
            Spacer(Modifier.width(8.dp))
            Text("التشخيص", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = C.text)
        }
        Text("الحالة: ${s.status}. السجل ده فيه كل خدمات الساعة وكل البيانات الخام اللي بتبعتها. انسخه وابعته لـ Claude.", color = C.dim, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("log", lines.joinToString("\n")))
                toast(ctx, "اتنسخ السجل")
            }) { Text("نسخ السجل") }
            OutlinedButton(onClick = { BleService.log.value = emptyList() }) { Text("مسح") }
        }
        Column(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card).padding(8.dp)) {
            LazyColumn(reverseLayout = true) {
                items(lines.reversed()) { Text(it, color = C.text, fontSize = 11.sp) }
            }
        }
        OutlinedTextField(value = uuid, onValueChange = { uuid = it }, label = { Text("UUID الخاصية (مثال: FFF6)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = hex, onValueChange = { hex = it }, label = { Text("HEX (مثال: 01 02 FF)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = { toast(ctx, BleService.instance?.sendRaw(uuid, hex) ?: "الخدمة مش شغالة") }, modifier = Modifier.fillMaxWidth()) { Text("إرسال للساعة") }
    }
}

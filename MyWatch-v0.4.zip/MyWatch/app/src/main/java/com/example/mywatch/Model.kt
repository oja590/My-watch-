package com.example.mywatch

import java.util.UUID

/** كل القراءات هنا بتيجي من الساعة زي ما هي. null = الساعة لسه ما بعتتش القراءة دي. */
data class WatchState(
    val status: String = "غير متصلة",
    val connected: Boolean = false,
    val deviceName: String? = null,
    val hr: Int? = null,
    val spo2: Int? = null,
    val sys: Int? = null,
    val dia: Int? = null,
    val temp: Float? = null,
    val water: Int? = null,
    val battery: Int? = null,
    val steps: Int? = null,
    val distanceM: Int? = null,
    val calories: Int? = null,
    val sleepMin: Int? = null,
    val stress: Int? = null,        // الضغط النفسي 0..100
    val activeMin: Int? = null,     // دقائق النشاط اليومية
    val workoutMin: Int? = null,    // حركة الساعة: المدة بالدقايق
    val workoutHr: Int? = null,     // حركة الساعة: متوسط النبض
    val workoutCal: Int? = null,    // حركة الساعة: السعرات
    val runM: Int? = null,          // جري GPS: المسافة بالمتر
    val runMin: Int? = null,        // جري GPS: المدة بالدقايق
    val runPaceSec: Int? = null,    // جري GPS: ثواني لكل كم
    val runCal: Int? = null,        // جري GPS: السعرات
    val weatherC: Int? = null,      // من الإنترنت (مش من الساعة)
    val weatherCode: Int? = null,   // من الإنترنت (مش من الساعة)
    val lastSync: Long = 0
)

fun u16(x: Int): UUID = UUID.fromString(String.format("0000%04x-0000-1000-8000-00805f9b34fb", x))

fun ByteArray.hex(): String = joinToString(" ") { String.format("%02X", it) }

typealias Packets = List<Pair<UUID, ByteArray>>

interface Io {
    fun write(char: UUID, data: ByteArray)
    fun read(char: UUID)
    fun subscribe(char: UUID)
}

/**
 * الجزء الوحيد الخاص بالساعة. كل دالة بترجّع قايمة حزم (UUID الكتابة + البايتات).
 * قايمة فاضية = الميزة دي لسه مش متعرّفة للساعة دي.
 * هنكملها بعد ما نفك البروتوكول من شاشة التشخيص.
 */
interface WatchProtocol {
    fun onReady(io: Io) {}
    fun onData(char: UUID, data: ByteArray, s: WatchState): WatchState = s
    fun timeSync(): Packets = emptyList()
    fun notification(app: String, title: String, text: String): Packets = emptyList()
    fun weather(tempC: Int, wmoCode: Int): Packets = emptyList()
    fun setAlarm(hour: Int, minute: Int, enabled: Boolean): Packets = emptyList()
    /** صورة خلفية/واجهة الساعة بصيغة RGB565 (little-endian) بمقاس w×h. فاضية = لسه مش متعرّفة. */
    fun watchFace(w: Int, h: Int, rgb565: ByteArray): Packets = emptyList()
    /** kind: hr / spo2 / bp / temp / water / stress */
    fun measure(kind: String): Packets = emptyList()
}

class GenericProtocol : WatchProtocol {
    private val hrChar = u16(0x2A37)
    private val batChar = u16(0x2A19)

    override fun onReady(io: Io) {
        io.subscribe(hrChar)
        io.read(batChar)
    }

    override fun onData(char: UUID, data: ByteArray, s: WatchState): WatchState {
        if (char == hrChar && data.size >= 2) {
            val is16 = (data[0].toInt() and 1) == 1
            val v = if (is16 && data.size >= 3)
                ((data[2].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
            else data[1].toInt() and 0xFF
            return if (v in 30..220) s.copy(hr = v) else s
        }
        if (char == batChar && data.isNotEmpty()) {
            val b = data[0].toInt() and 0xFF
            return if (b in 0..100) s.copy(battery = b) else s
        }
        // TODO: هنا بنفك حزم الخطوات والنوم والضغط والأكسجين والحرارة والماء بعد ما نعرف شكلها.
        return s
    }
}

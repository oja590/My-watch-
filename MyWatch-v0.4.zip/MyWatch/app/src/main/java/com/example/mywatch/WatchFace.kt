package com.example.mywatch

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** تصميم واجهة ساعة: style = رقم الشكل (0..9)، والباقي ألوان ARGB. */
data class FaceDesign(val id: Int, val name: String, val style: Int, val bg1: Int, val bg2: Int, val accent: Int, val text: Int)

private fun col(h: Long): Int = h.toInt()

private data class Pal(val name: String, val bg1: Long, val bg2: Long, val accent: Long, val text: Long)

private val PALS = listOf(
    Pal("أخضر ليلي", 0xFF0E1116, 0xFF1A1F27, 0xFF22C55E, 0xFFF1F5F9),
    Pal("أزرق ليلي", 0xFF0B1220, 0xFF16254A, 0xFF38BDF8, 0xFFFFFFFF),
    Pal("غروب", 0xFF2B0A3D, 0xFF7A1F5C, 0xFFFB923C, 0xFFFFF7ED),
    Pal("أحمر ناري", 0xFF1A0505, 0xFF4A0D12, 0xFFFF4D6D, 0xFFFFFFFF),
    Pal("بنفسجي", 0xFF140A2E, 0xFF2E1A5C, 0xFF8B5CF6, 0xFFF5F3FF),
    Pal("ذهبي", 0xFF111111, 0xFF2A2412, 0xFFFACC15, 0xFFFFFBEB),
    Pal("فيروزي", 0xFF06201F, 0xFF0B4A47, 0xFF2DD4BF, 0xFFF0FDFA),
    Pal("أبيض نظيف", 0xFFF8FAFC, 0xFFE2E8F0, 0xFF0EA5E9, 0xFF0F172A),
    Pal("كريمي", 0xFFFFF7ED, 0xFFFDE7C8, 0xFFEA580C, 0xFF3B2A1A),
    Pal("وردي", 0xFFFFF1F2, 0xFFFECDD3, 0xFFE11D48, 0xFF4C0519),
    Pal("فحمي", 0xFF18181B, 0xFF27272A, 0xFFA1A1AA, 0xFFFAFAFA),
    Pal("غابة", 0xFF052E16, 0xFF14532D, 0xFF86EFAC, 0xFFF0FDF4),
    Pal("بحري", 0xFF0A1F44, 0xFF123A7A, 0xFF60A5FA, 0xFFEFF6FF),
    Pal("برتقالي", 0xFF1C1004, 0xFF4A2508, 0xFFF97316, 0xFFFFF7ED),
    Pal("ليموني", 0xFF0F1A05, 0xFF26400A, 0xFFA3E635, 0xFFF7FEE7),
    Pal("عنابي", 0xFF2A0612, 0xFF5C0F2A, 0xFFF472B6, 0xFFFDF2F8),
    Pal("رملي", 0xFF2B2218, 0xFF4A3B28, 0xFFFBBF24, 0xFFFEF3C7),
    Pal("جليدي", 0xFF0C1A2B, 0xFF1E3A5F, 0xFF67E8F9, 0xFFECFEFF),
    Pal("أسود نقي", 0xFF000000, 0xFF000000, 0xFFFFFFFF, 0xFFFFFFFF),
    Pal("نيون", 0xFF0D0221, 0xFF2A0A4A, 0xFFF0ABFC, 0xFFFAF5FF)
)

private val STYLE_NAMES = listOf("رقمي", "رقمي بخط", "عقارب كلاسيك", "عقارب بسيط", "حلقة", "أرقام مكدّسة", "يسار", "عقارب ونقاط", "بلوك", "مفرّغ")

/** 20 تصميم جاهز. */
val FACE_DESIGNS: List<FaceDesign> = PALS.mapIndexed { i, p ->
    val style = (i + (i / 10) * 3) % 10
    FaceDesign(i, "${STYLE_NAMES[style]} — ${p.name}", style, col(p.bg1), col(p.bg2), col(p.accent), col(p.text))
}

val ACCENT_CHOICES: List<Int> = listOf(
    0xFF22C55E, 0xFF38BDF8, 0xFFFB923C, 0xFFFF4D6D, 0xFF8B5CF6,
    0xFFFACC15, 0xFF2DD4BF, 0xFFF472B6, 0xFFA3E635, 0xFFFFFFFF
).map { col(it) }

val BG_CHOICES: List<Int> = listOf(
    0xFF000000, 0xFF0E1116, 0xFF0B1220, 0xFF1A0505, 0xFF140A2E, 0xFF052E16, 0xFF2B2218, 0xFFF8FAFC
).map { col(it) }

private fun paint(color: Int, style: Paint.Style = Paint.Style.FILL, sw: Float = 0f, size: Float = 0f,
                  bold: Boolean = false, align: Paint.Align = Paint.Align.CENTER): Paint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        this.style = style
        strokeWidth = sw
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        textAlign = align
        strokeCap = Paint.Cap.ROUND
    }

private fun txt(cv: Canvas, s: String, x: Float, baseline: Float, size: Float, color: Int,
                bold: Boolean = true, align: Paint.Align = Paint.Align.CENTER) {
    cv.drawText(s, x, baseline, paint(color, size = size, bold = bold, align = align))
}

private fun hand(cv: Canvas, cx: Float, cy: Float, len: Float, deg: Float, p: Paint) {
    val r = Math.toRadians((deg - 90).toDouble())
    cv.drawLine(cx, cy, (cx + len * Math.cos(r)).toFloat(), (cy + len * Math.sin(r)).toFloat(), p)
}

private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

/**
 * بيرسم الواجهة في Bitmap بحجم الساعة. نفس الدالة بتستخدم للمعاينة وللإرسال للساعة.
 */
fun renderFace(
    d: FaceDesign, accentOv: Int?, bgOv: Int?, img: Bitmap?, showDate: Boolean,
    w: Int, h: Int, cal: Calendar = Calendar.getInstance()
): Bitmap {
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val W = w.toFloat(); val H = h.toFloat()
    val cx = W / 2; val cy = H / 2; val m = minOf(W, H)
    val accent = accentOv ?: d.accent

    // ---- الخلفية ----
    var textC = d.text
    if (img != null) {
        val sr = minOf(img.width / W, img.height / H)
        val sw = (W * sr).toInt(); val sh = (H * sr).toInt()
        val sx = (img.width - sw) / 2; val sy = (img.height - sh) / 2
        cv.drawBitmap(img, Rect(sx, sy, sx + sw, sy + sh), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        cv.drawRect(0f, 0f, W, H, paint(Color.argb(90, 0, 0, 0)))
        textC = Color.WHITE
    } else {
        val c1 = bgOv ?: d.bg1
        val c2 = bgOv ?: d.bg2
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, 0f, H, c1, c2, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, W, H, p)
        if (bgOv != null) {
            // لو الخلفية فاتحة نخلي النص غامق، والعكس.
            val lum = (0.299 * Color.red(bgOv) + 0.587 * Color.green(bgOv) + 0.114 * Color.blue(bgOv))
            textC = if (lum > 150) Color.parseColor("#0F172A") else Color.WHITE
        }
    }

    val hh = cal.get(Calendar.HOUR_OF_DAY)
    val mm = cal.get(Calendar.MINUTE)
    val time = String.format(Locale.US, "%02d:%02d", hh, mm)
    val date = if (showDate) SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(cal.time) else ""

    when (d.style) {
        0 -> {
            val s = m * 0.30f
            txt(cv, time, cx, cy + s * 0.2f, s, textC)
            if (date.isNotEmpty()) txt(cv, date, cx, cy + m * 0.30f, m * 0.075f, accent, bold = false)
        }
        1 -> {
            val s = m * 0.28f
            txt(cv, time, cx, cy, s, textC)
            cv.drawRoundRect(RectF(cx - m * 0.25f, cy + m * 0.08f, cx + m * 0.25f, cy + m * 0.105f), 12f, 12f, paint(accent))
            if (date.isNotEmpty()) txt(cv, date, cx, cy + m * 0.26f, m * 0.075f, textC, bold = false)
        }
        2, 3, 7 -> {
            val r = m * 0.44f
            if (d.style == 2) {
                cv.drawCircle(cx, cy, r, paint(withAlpha(textC, 70), Paint.Style.STROKE, m * 0.012f))
                for (i in 0 until 60) {
                    val big = i % 5 == 0
                    val len = if (big) m * 0.06f else m * 0.025f
                    val a = Math.toRadians((i * 6 - 90).toDouble())
                    val p = paint(if (big) accent else withAlpha(textC, 140), Paint.Style.STROKE, if (big) m * 0.014f else m * 0.007f)
                    cv.drawLine(
                        (cx + r * Math.cos(a)).toFloat(), (cy + r * Math.sin(a)).toFloat(),
                        (cx + (r - len) * Math.cos(a)).toFloat(), (cy + (r - len) * Math.sin(a)).toFloat(), p
                    )
                }
            } else {
                val dots = if (d.style == 3) 4 else 12
                for (i in 0 until dots) {
                    val a = Math.toRadians((i * (360.0 / dots) - 90))
                    cv.drawCircle((cx + (r - m * 0.04f) * Math.cos(a)).toFloat(), (cy + (r - m * 0.04f) * Math.sin(a)).toFloat(),
                        if (i % 3 == 0 || d.style == 3) m * 0.018f else m * 0.01f, paint(accent))
                }
            }
            hand(cv, cx, cy, r * 0.5f, (hh % 12 + mm / 60f) * 30f, paint(textC, Paint.Style.STROKE, m * 0.03f))
            hand(cv, cx, cy, r * 0.76f, mm * 6f, paint(if (d.style == 3) accent else textC, Paint.Style.STROKE, m * 0.02f))
            cv.drawCircle(cx, cy, m * 0.03f, paint(accent))
            if (d.style == 7) txt(cv, time, cx, cy + r * 0.62f, m * 0.085f, textC)
            else if (date.isNotEmpty()) txt(cv, date, cx, cy + r * 0.55f, m * 0.065f, accent, bold = false)
        }
        4 -> {
            val r = m * 0.42f
            val rect = RectF(cx - r, cy - r, cx + r, cy + r)
            cv.drawArc(rect, 0f, 360f, false, paint(withAlpha(accent, 50), Paint.Style.STROKE, m * 0.05f))
            cv.drawArc(rect, -90f, mm / 60f * 360f, false, paint(accent, Paint.Style.STROKE, m * 0.05f))
            val s = m * 0.22f
            txt(cv, time, cx, cy + s * 0.2f, s, textC)
            if (date.isNotEmpty()) txt(cv, date, cx, cy + m * 0.2f, m * 0.065f, accent, bold = false)
        }
        5 -> {
            val s = m * 0.40f
            txt(cv, String.format(Locale.US, "%02d", hh), cx, cy - m * 0.02f, s, accent)
            txt(cv, String.format(Locale.US, "%02d", mm), cx, cy + m * 0.36f, s, textC)
            if (date.isNotEmpty()) txt(cv, date, cx, m * 0.12f, m * 0.07f, textC, bold = false)
        }
        6 -> {
            val x = W * 0.16f
            cv.drawRoundRect(RectF(W * 0.07f, H * 0.30f, W * 0.09f, H * 0.70f), 10f, 10f, paint(accent))
            if (date.isNotEmpty()) txt(cv, date, x, cy - m * 0.17f, m * 0.07f, accent, bold = false, align = Paint.Align.LEFT)
            txt(cv, time, x, cy + m * 0.08f, m * 0.22f, textC, align = Paint.Align.LEFT)
        }
        8 -> {
            cv.drawRoundRect(RectF(W * 0.1f, H * 0.1f, W * 0.9f, H * 0.3f), m * 0.06f, m * 0.06f, paint(accent))
            val onAccent = if (Color.red(accent) * 0.299 + Color.green(accent) * 0.587 + Color.blue(accent) * 0.114 > 150) Color.BLACK else Color.WHITE
            if (date.isNotEmpty()) txt(cv, date, cx, H * 0.1f + (H * 0.2f) / 2 + m * 0.03f, m * 0.08f, onAccent)
            txt(cv, time, cx, cy + m * 0.2f, m * 0.30f, textC)
        }
        else -> {
            val s = m * 0.30f
            cv.drawText(time, cx, cy + s * 0.2f, paint(accent, Paint.Style.STROKE, m * 0.014f, s, true))
            if (date.isNotEmpty()) txt(cv, date, cx, cy + m * 0.30f, m * 0.075f, textC, bold = false)
        }
    }
    return bmp
}
